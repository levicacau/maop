#! /bin/bash
javac ksk_full.java
java ksk_full temp.txt